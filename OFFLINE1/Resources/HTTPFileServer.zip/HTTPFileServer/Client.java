import java.io.*;
import java.net.Socket;

public class Client {
    private static DataOutputStream dataOutputStream = null;
    private static DataInputStream dataInputStream = null;

    public static void main(String[] args) throws IOException {
        Socket socket = new Socket("localhost",3000);
        dataInputStream = new DataInputStream(socket.getInputStream());
        dataOutputStream = new DataOutputStream(socket.getOutputStream());

        sendFile("E:/L3-T2/CSE 322/offline1/HTTPFileServer/File/test.txt");

//        dataInputStream.close();
//        dataOutputStream.close();

    }

    private static void sendFile(String path) throws IOException {
        int bytes = 0;

        File file = new File(path);
        FileInputStream fileInputStream
                = new FileInputStream(file);
        dataOutputStream.writeLong(file.length());

        byte[] buffer = new byte[4 * 1024];
        while ((bytes = fileInputStream.read(buffer))
                != -1) {
            // Send the file to Server Socket
            dataOutputStream.write(buffer, 0, bytes);
            dataOutputStream.flush();
        }
        fileInputStream.close();
    }
}
