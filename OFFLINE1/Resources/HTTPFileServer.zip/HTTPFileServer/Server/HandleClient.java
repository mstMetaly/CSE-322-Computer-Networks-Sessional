package Server;

import java.io.*;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.Date;

public class HandleClient {

    public HandleClient()
    {

    }

    public static void sendErrorResponse(PrintWriter pr , int statusCode , String statusMessage , String errorMessage)
    {
        String s = "<html><body>" + "<h1>" + statusCode + " " + statusMessage + "</h1>" +
                "<p>" + errorMessage + "</p>" + "</body></html>";
        StringBuilder responseBody = new StringBuilder(s);

        pr.write("HTTP/1.1 " + statusCode + " " + statusMessage + "\r\n");
        pr.write("Server: Java HTTP Server: 1.0\r\n");
        pr.write("Date: " + new Date() + "\r\n");
        pr.write("Content-Type: text/html"+"\r\n");
        pr.write("Content-Length: " + responseBody.length() + "\r\n");
        pr.write("\r\n");
        pr.write(String.valueOf(responseBody));
        pr.flush();
    }

    public static void sendDirectoryResponse(StringBuilder responseBody, PrintWriter pr ,String contentType)
    {
        pr.write("HTTP/1.1 200 OK\r\n");
        pr.write("Server: Java HTTP Server: 1.0\r\n");
        pr.write("Date: " + new Date() + "\r\n");
        pr.write("Content-Type: "+contentType +"\r\n");
        pr.write("Content-Length: " + responseBody.length() + "\r\n");
        pr.write("\r\n");
        pr.write(String.valueOf(responseBody));
        pr.flush();

    }

    public static void sendFileResponse(PrintWriter pr, OutputStream outputStream , File file , String contentType ) throws IOException {
        pr.write("HTTP/1.1 200 OK\r\n");
        pr.write("Content-Type: " + contentType + "\r\n");
        pr.write("Content-Length: " + file.length() + "\r\n");
        pr.write("\r\n"); // End of headers
        pr.flush();

        FileInputStream fileInputStream = new FileInputStream(file);
        byte[] buffer = new byte[4096];
        int bytesRead;
        while((bytesRead = fileInputStream.read(buffer)) != -1)
        {
            outputStream.write(buffer , 0 , bytesRead);
        }
        outputStream.flush();
    }


    public static String extractPath(String input) throws UnsupportedEncodingException {
        String path = "";
        if(input == null)
            return "";
        else if(input.equalsIgnoreCase("GET /favicon.ico HTTP/1.1"))
            return "";
        else if(input.startsWith("GET")){
            String[] requestParts = input.split(" /");
            String tempPath = requestParts[1];
            String[] temp = tempPath.split(" HTTP/1.1");
            path = temp[0];
        }

        String decodedPath = URLDecoder.decode(path, StandardCharsets.UTF_8.toString());
        return decodedPath;

    }

    public static String getContentType(File file) {
        String fileName = file.getName().toLowerCase();
        if(fileName.endsWith("txt"))
            return "text/html";
        if (fileName.endsWith(".jpg") || fileName.endsWith(".jpeg")) {
            return "image/jpeg";
        } else if (fileName.endsWith(".png")) {
            return "image/png";
        } else if (fileName.endsWith(".gif")) {
            return "image/gif";
        } else {
            return "application/octet-stream";
        }
    }



    //handle file
    public static void  handleFile(String path , StringBuilder responseBody , PrintWriter pr , OutputStream outputStream) throws IOException {

        File file = new File(path);
        if(file.exists())
        {
            String contentType = getContentType(file);
            sendFileResponse(pr,outputStream,file,contentType);

//            if(contentType.equalsIgnoreCase("text/html"))
//            {
//                sendFileResponse(pr,outputStream,file,contentType);
//            }
//            else if(contentType.equalsIgnoreCase("image/jpeg") || contentType.equalsIgnoreCase("image/png") ||
//                    contentType.equalsIgnoreCase("image/gif"))
//            {
//                sendFileResponse(pr,outputStream,file,contentType);
//            }
//            else{
//                sendFileResponse(pr,outputStream,file,contentType);
//            }

        }
        else{
            sendErrorResponse(pr,404,"NOT FOUND", "File Not Found");
        }

    }


    //list all files for decoded path
    public static void handlePath(String decodedPath , StringBuilder responseBody , PrintWriter pr , OutputStream outputStream) throws IOException {
        File directory = new File(decodedPath);
        File[] files = null;

        if(directory.isDirectory())
        {
            files = directory.listFiles();
            for(File file : files)
            {
                String fullPath = decodedPath + "/" + file.getName();  // Ensure full relative path
                fullPath = fullPath.replace(" ", "%20");
                if (!fullPath.startsWith("/")) {
                    fullPath = "/" + fullPath;
                }
                System.out.println("Full path: "+ fullPath);
                responseBody.append("<li><a href=\"").append(fullPath).append("\">").append(file.getName()).append("</a></li>");
            }

            responseBody.append("</body></html>");
            sendDirectoryResponse(responseBody , pr , "text/html");//??
        }
        else
        {
            handleFile(decodedPath , responseBody ,pr, outputStream);
        }

    }


    //create response body
    public static void handleGetRequest(String input , PrintWriter pr , OutputStream outputStream) throws IOException {

        String decodedPath = extractPath(input);

        if(decodedPath == null)
        {
            sendErrorResponse(pr,404, "Not found", "No path exists like this");
            System.out.println("Path not found!");
        }

        String s = "<html><body><h1>Directory listing for " + decodedPath + "</h1><ul>";
        StringBuilder responseBody = new StringBuilder(s);

        //handle the directory/file
        handlePath(decodedPath , responseBody , pr ,outputStream);

    }


    //handles client request
    public static void handleClientRequest(Socket socket) throws IOException {

        //initializing input stream
        InputStream inputStream = socket.getInputStream();
        BufferedReader in = new BufferedReader(new InputStreamReader(inputStream));
        BufferedInputStream bufferedInputStream = new BufferedInputStream(inputStream);

        //initializing outputStream
        OutputStream outputStream = socket.getOutputStream();
        PrintWriter pr = new PrintWriter(outputStream);

        //for upload
         String input = in.readLine();

        if(input != null)
            System.out.println("request: " + input);

        if(input == null)
        {
            return;
        }
        if (input != null && input.contains("/favicon.ico")) {
            System.out.println("Ignoring /favicon.ico request");
            pr.write("HTTP/1.1 204 No Content\r\n");
            pr.write("Server: Java HTTP Server: 1.0\r\n");
            pr.write("Date: " + new Date() + "\r\n");
            pr.write("Content-Length: 0\r\n");
            pr.write("\r\n");
            pr.flush();

            return;  // Exit the method to stop processing this request
        }
        if(input.startsWith("GET"))
        {
            handleGetRequest(input, pr , outputStream );
        }
        else if(input.startsWith("UPLOAD"))
        {
           handleUploadfile(in ,bufferedInputStream, input);
        }


    }


    //
    public  static  void handleUploadfile(BufferedReader in , BufferedInputStream bufferedInputStream, String input) throws IOException {
        System.out.println("in handle upload file");
        String[] arr = input.split(" ");
        String fileName = arr[1];

        long fileSize = Long.parseLong(in.readLine());

        //handle upload directory
        File uploadDir = new File("E:/L3-T2/CSE 322/offline1/HTTPFileServer/Server/uploaded/");

        ///extra
//        String currentDir = System.getProperty("user.dir");
//        File uploadDir = new File(currentDir, "Server/uploaded");
//
//        if (!uploadDir.exists()) {
//            boolean created = uploadDir.mkdirs();
//            if (created) {
//                System.out.println("Upload directory created at: " + uploadDir.getAbsolutePath());
//            } else {
//                System.err.println("Failed to create upload directory.");
//            }
//        } else {
//            System.out.println("Upload directory already exists at: " + uploadDir.getAbsolutePath());
//        }


        //Receive file data using file input stream
        File file = new File(uploadDir, fileName);
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        byte[] buffer = new byte[4096];
        int bytesRead ;
        int totalBytesRead = 0;
        while(totalBytesRead < fileSize && (bytesRead = bufferedInputStream.read(buffer)) != -1)
        {
            fileOutputStream.write(buffer , 0 , bytesRead);
            totalBytesRead+=bytesRead;
        }
        fileOutputStream.close();
        System.out.println("File Received");

    }


}
