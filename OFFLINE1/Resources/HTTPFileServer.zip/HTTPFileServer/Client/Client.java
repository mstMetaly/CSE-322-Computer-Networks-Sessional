package Client;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.URL;
import java.util.Scanner;

public class Client {

    private static final String BOUNDARY = "----WebKitFormBoundary7MA4YWxkTrZu0gW";

    public static void main(String[] args) throws IOException {

        Socket socket = new Socket("localhost",3000);
        System.out.println("Client connnected.");
        Scanner sc = new Scanner(System.in);


        OutputStream outputStream = socket.getOutputStream();
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream));
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(outputStream);

        while (true)
        {
            System.out.print("Enter Command + fileName : ");
            String input = sc.nextLine();
            String[] arr = input.split(" ");
            String fileName = arr[1];

            //extra
//            String currentDir = System.getProperty("user.dir");
//            File fileDir = new File(currentDir, "Client/upload");
//            File file = new File(fileDir,fileName);

            File file = new File("E:/L3-T2/CSE 322/offline1/HTTPFileServer/Client/upload/",fileName);

            if(file.exists())
            {
                bufferedWriter.write("UPLOAD "+ fileName + "\n");
                bufferedWriter.write(file.length() + "\n");
                bufferedWriter.flush();

                //send the file data using FileInputStream
                FileInputStream fileInputStream = new FileInputStream(file);

                byte[] buffer = new byte[4096];
                int bytesRead;
                while((bytesRead = fileInputStream.read(buffer)) != -1)
                {
                    bufferedOutputStream.write(buffer , 0 , bytesRead);
                }
                bufferedOutputStream.flush();

                fileInputStream.close();
                System.out.println("File upload completed");

            }

        }

    }

}
