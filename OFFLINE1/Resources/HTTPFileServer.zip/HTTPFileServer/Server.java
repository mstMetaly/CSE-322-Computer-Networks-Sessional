import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

import static java.lang.Math.min;

public class Server {
    public  static  void receiveFile(String fileName , DataInputStream dataInputStream) throws IOException {

        int bytes = 0;
        File file = new File("E:/L3-T2/CSE 322/offline1/HTTPFileServer",fileName);
        FileOutputStream fileOutputStream = new FileOutputStream(file);

        long size = dataInputStream.readLong();
        byte[] buffer = new byte[4096];

        while(size > 0 && (bytes = dataInputStream.read(buffer,0,(int)Math.min(buffer.length,size))) != -1)
        {
            fileOutputStream.write(buffer,0,bytes);
            size -= bytes;
        }

        System.out.println("File received");
        fileOutputStream.close();
    }



    public static void main(String[] args) throws IOException {
        ServerSocket serverSocket = new ServerSocket(3000);
        System.out.println("Server strated");

        while(true)
        {
            Socket socket = serverSocket.accept();

            DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
            DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());

            receiveFile("newFile1.txt",dataInputStream);

//            dataInputStream.close();
//            dataOutputStream.close();
        }

    }
}
